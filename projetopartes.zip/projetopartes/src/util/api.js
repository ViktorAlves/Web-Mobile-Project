import informativos from "@/components/informativos"

//------------ CRIAR ----------
export async function adicionarInformativos(informativos){
    let response = await fetch("http://localhost:8000/informativos",
    {
        method: 'POST',
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(informativos)
    })
    return response.status
}

//-------------- LEIITURA --------------
export async function buscarInformativos(){
    let response = await fetch("http://localhost:8000/informativos")
    let dado = await response.json()
    return dado
}


//-------------- ATUALIZAR -------------
export async function atualizarInformativos(informativos){
    let response = await fetch("http://localhost:8000/informativos/" + informativo.id,
    {
        method: 'PUT',
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(informativos)
    })
    return response.status
}

//--------------- DELETAR----------------
export async function deletarInformativos(id){
    let response = await fetch("http://localhost:8000/informativos/" + id,
    {
        method: 'DELETE'
    })
    return response.status
}