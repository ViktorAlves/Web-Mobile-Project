import informativos from "@/components/informativos"

//------------ CRIAR ----------
export async function adicionarInformativos(informativo){
    let response = await fetch("http://localhost:8000/informativos",
    {
        method: 'POST',
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(informativo)
    })
    return response.status
}

//-------------- LEIITURA --------------
export async function buscarInformativos(){
    let response = await fetch("http://localhost:8000/informativos")
    let dado = await response.json()
    return dado
}

export async function buscarStatus(situacao){
    let response = await fetch (`http://localhost:8000/informativos?situacao=${situacao}`)
    let dado = await response.json()
    return dado
}

//-------------- ATUALIZAR -------------
export async function atualizarInformativos(informativo){
    let response = await fetch("http://localhost:8000/informativos/" + informativo.id,
    {
        method: 'PUT',
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(informativo)
    })
    return response.status
}

export async function deletarInformativos(id){
    let response = await fetch("http://localhost:8000/informativos/" + id,
    {
        method: 'DELETE'
    })
    return response.status
}