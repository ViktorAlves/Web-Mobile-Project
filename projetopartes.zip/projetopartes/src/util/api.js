import informativos from "@/components/informativos"

//------------ CRIAR ----------
export async function addInfo(info){
    try{
        let response = await fetch("http://localhost:8000/informativos", 
        {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(info)
        })
        return response.status
    } catch(error) {
        console.log("ERROR: " + error)
    }
}

//-------------- LEIITURA --------------
export async function getInfo(){
    try{
        let response = await fetch("http://localhost:8000/informativos")
        let data = await response.json()
        return data
    } catch(error) {
        console.log("ERROR: " + error)
    }
}


//-------------- ATUALIZAR -------------
export async function updateInfo(info){
    try{
        let response = await fetch("http://localhost:8000/informativos/" + info.id, 
        {
            method: 'PUT',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(info)
        })
        return response.status
    } catch(error) {
        console.log("ERROR: " + error)
    }
}

//--------------- DELETAR----------------
export async function deleteInfo(id){
    try{
        let response = await fetch("http://localhost:8000/informativos/" + id, 
        {
            method: 'DELETE'
        })
        return response.status
    } catch(error) {
        console.log("ERROR: " + error)
    }
}