import MenuItem from "@/components/menuItem";
import Menu from "@/components/menu";
import ApiWeather from "@/components/api";
export default function Home() {
  return (
    <main>
      <Menu/>
      <h1 className="titulo">Sobre o nosso projeto</h1>
      <p className="texto_pagina1A"> 
            Nosso projeto tem como objetivo informar acerca da poluição do ar,
            do solo e das águas, pois a melhor maneira de se evitar problemas,
            independente de qual ele seja, é com a educação, mostrando
            graficamente a poluição do ar e com o intuito de usá-lo para alertar
            as autoridades responsáveis para que tomem alguma medida com a
            finalidade de resolução do problema descrito no aplicativo. Tivemos
            como alvo o objetivo 3.9 Até 2030, reduzir substancialmente o número
            de mortes e doenças por produtos químicos perigosos, contaminação e
            poluição do ar e da água do solo, focado na comunidade da região
            metropolitana de São Paulo.
        </p>
        <div className="moldura"></div>
          <div className="texto_pagina1B">
            <img className="foto" alt="Foto" src="/poluicao.png" />
          </div>
          <p className="p">
            Além de causar doenças respiratórias e problemas de saúde, a
            poluição do ar, do solo e das águas pode afetar negativamente os
            ecossistemas, a biodiversidade e até mesmo a economia de uma região.
            Falaremos sobre as fontes principais de poluição no mundo, citar as
            principais consequências e alguma das contramedidas.
          </p>
    </main>
  );
}
