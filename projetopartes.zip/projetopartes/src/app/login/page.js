import Menu from "@/components/menu";
import MenuItem from "@/components/menuItem";
export default function Home(){
    return(
        <main>
            <Menu/>
            <h1>CADASTRO</h1>
          <label htmlFor="nome">Nome:</label>
          <br />
          <input
            type="text"
            id="nome"
            name="nome"
            required
            placeholder="nome"
          />
          <br />
          <label htmlFor="sobrenome"></label>
          <br />
          <input
            type="text"
            id="sobrenome"
            name="sobrenome"
            required
            placeholder="sobrenome"
          />
          <br />
          <label htmlFor="email"></label>
          <br />
          <input
            type="email"
            id="email"
            name="email"
            required
            placeholder="email"
          />
          <br />
          <label htmlFor="senha"></label>
          <br />
          <input
            type="password"
            id="senha"
            name="senha"
            required
            placeholder="senha"
          />
          <br />
          <label htmlFor="confirmar_senha"></label>
          <br />
          <input
            type="password"
            id="confirmar_senha"
            name="confirmar_senha"
            placeholder="confirmar senha"
            required
          />
          <br />
          <button type="submit">Confirmar Cadastro</button>
          <br></br>
          
          <h1>LOGIN</h1>
          <label htmlFor="email"></label>
          <br />
          <input
            type="email"
            id="email"
            name="email"
            required
            placeholder="email"
          />
          <br />
          <label htmlFor="senha"></label>
          <br />
          <input
            type="password"
            id="senha"
            name="senha"
            required
            placeholder="senha"
          />
          <br />
          <button type="submit">Login</button>
        </main>
    )
}