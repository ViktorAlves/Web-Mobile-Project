"use client"


import { adicionarInformativos, atualizarInformativos, buscarInformativos, deletarInformativos } from "@/util/api.js"
import { useEffect, useState } from "react"
import styles from "@/app/relatos/relatos.module.css"
import {v4 as uuid} from "uuid"
import Menu from "@/components/menu"
import MenuItem from "@/components/menuItem"
import Informativos from "@/components/informativos"



function Home(){
    const [informativo, setInformativo] = useState(null)
    const [id, setId] = useState("")
    const [cidade, setCidade] = useState("")
    const [situacao, setSituacao]=useState("")
    const [informativos, setInformativos] = useState(null)
    useEffect(()=>{
        buscarInformativos()
        .then((dado)=>{setInformativo(dado)})
    },[])
    function mudarId(event){
        setId(event.target.value)
    }
    function mudarEndereco(event){
        setCidade(event.target.value)
    }
    function mudarRelato(event){
        setInformativo(event.target.value)
    }
    function mudarStatus(event){
        setSituacao(event.target.value)
    }

    function addRelato(){
        let id = uuid()
        let texto = texto
        let info = {id, informativo, cidade, situacao}

        adicionarInformativos(dado).then((status)=>{
            if(status == 201 || status== 200){
                buscarInformativos()
                .then((dado)=>setInformativo(dado))
            }
        })
    }

    function delRelato(){
        deletarInformativos(id).then((status)=>{
            if(status == 200){
                buscarInformativos()
                .then((dado)=> setInformativo(dado))
            }
        })
    }

    function attRelato(){
        let texto = informativo
        let info = {id, informativo, cidade, situacao}
        atualizarInformativos(info).then((status)=>{
            if(status == 200){
                buscarInformativos()
                .then((dado)=>setInformativo(dado))
            }
        })
    }
    return(
        <main>
            <Menu/>
            <form>
                <p>ID:<br/><input type="text" onChange={mudarId}/></p>
                <p>Endereço:<br/><input type="text" onChange={mudarEndereco}/></p>
                <p>Relato:<br/><textarea onChange={mudarRelato}></textarea></p>
                <p>Status:<br/><input type="text" onChange={mudarStatus}/></p>
                <button onClick={addRelato}>Adicionar</button>
                <button onClick={delRelato}>Apagar</button>
                <button onClick={attRelato}>Atualizar</button>
            </form>
            <section>
                {informativos
                    ? (informativos.map((info)=><Informativos texto={info}/>))
                    : (<p>Carregando...</p>)
                }
            </section>
        </main>
    )
}
export default Home;