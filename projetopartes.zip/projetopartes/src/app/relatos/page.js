"use client"


import { addInfo, adicionarInformativos, atualizarInformativos, buscarInformativos, deletarInformativos, deleteInfo, getInfo, updateInfo } from "@/util/api.js"
import { useEffect, useState } from "react"
import styles from "@/app/relatos/relatos.module.css"
import {v4 as uuid} from "uuid"
import Menu from "@/components/menu"
import MenuItem from "@/components/menuItem"
import Informativos from "@/components/informativos"



function Home(){

    const[infos, setInfos] = useState(null)
    const[info, setInfo] = useState("")
    const[situacao, setSituacao]=useState("")
    const[end, setEnd]=useState("")

    useEffect( ()=>{
        getInfo()
        .then( (data) => setInfos(data) )
      }, [] )
    
      function mudarInfo(event){
        setInfo(event.target.value)
      }
      
      function mudarSituacao(event){
        setSituacao(event.target.value)
      }
    
      function mudarEndereco(event){
        setEnd(event.target.value)
      }
    
      function addInfos(){
        event.preventDefault()
        console.log(end, info, situacao)
        let id = uuid()
        let text = info
    
        let q = { id, end, text, situacao}
    
        addInfo(q).then( (status)=>{
          if(status == 201) {
            getInfo()
              .then( (data) => setInfos(data) )
          }
        } )
      }
    
      function attInfos(event){
        event.preventDefault()
        let text = info
        let q = { id, end, text, situacao}
    
        updateInfo(q).then( (status)=>{
          if(status == 200) {
            getInfo()
              .then( (data) => setInfos(data) )
          }
        } )
      }
    
      function mudarID(event){
        setID(event.target.value)
      }
    
      function delInfos(){
        deleteInfo(id).then( (status) => {
          if(status == 200){
            getInfo()
              .then( (data) => setInfos(data) )
          }
        } )
      }
    return(
        <main>
            <Menu/>
            <form>
                <p>ID:<br/><input type="text" onChange={mudarID}/></p>
                <p>Endereço:<br/><input type="text" onChange={mudarEndereco}/></p>
                <p>Relato:<br/><textarea onChange={mudarInfo}></textarea></p>
                <p>Status:<br/><input type="text" onChange={mudarSituacao}/></p>
                <button onClick={addInfos}>Adicionar</button>
                <button onClick={delInfos}>Apagar</button>
                <button onClick={attInfos}>Atualizar</button>
            </form>
            <section>
                {infos
                    ? (infos.map((info)=><Informativos texto={info}/>))
                    : (<p>Carregando...</p>)
                }
            </section>
        </main>
    )
}
export default Home;