"use client"
import { useEffect, useState } from "react"
import styles from "./api.module.css"

export default function ApiWeather({city}){
    let baseUrl="https://api.openweathermap.org/data/2.5/weather?units=metric"
    let appiKey="5e328372daecd2568245de0dac63c13f"
    let lingua="pt_br"
    let url=baseUrl + `&q=${city}`+`&appid=${appiKey}`+`&lang=${lingua}`
    let [clima, setWeather]= useState(null)
    

    useEffect(getData,[])
    let content="loading..."

    if (clima){
        const date = new Date();
        const hora = date.getHours();
        const min = date.getMinutes();
        content = <div><p>cidade: {clima.name}</p><span>temperatura: {clima.main.temp}°C</span><p>{hora}:{min}</p><p>velocidade do vento: {clima.main.temp_max}</p><p>umidade: {clima.main.humidity}%</p></div>
    }
    function getData(){
        console.log(url)
        try {
            fetch(url)
            .then((response)=>response.json())
            .then((data)=>{
                setWeather(data)
            })
        } catch (error) {
            console.log(error)
        }
    }
    return(
        <div className={styles.api}>
            {content}
        </div>
    )

}