import styles from "./menu.module.css"
import MenuItem from "./menuItem"

export default function Menu() {
    return (
        <nav className={styles.menu}>
            <ul>
                <li> <MenuItem text="Página Inicial" route="/" icon="https://super.so/icon/light/home.svg"/> </li>
                <li> <MenuItem text="Informações" route="/informacao" icon="https://super.so/icon/light/user.svg"/> </li>
                <li> <MenuItem text="Login" route="/relatos" icon="https://super.so/icon/light/mail.svg" /> </li>
                <li> <menuItem text="SEI La" route="/relatos" icon="https://super.so/icon/light/mail.svg"/></li>
            </ul>
        </nav>
    )
}