import styles from "@/components/informativos.module.css"

export default function Informativos(informativos){
    return(
        <article className={styles.informativos}>
            <p><strong>{informativos.informativo}</strong></p>
            <p><small>{informativos.endereco}</small></p>
            <p><small>{informativos.situacao}</small></p>
            <p><small>{informativos.id}</small></p>
        </article>
    )
}