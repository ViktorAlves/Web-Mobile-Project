import styles from "@/components/informativos.module.css"

export default function Informativos({info}){
    return(
        <article className={styles.informativos}>
            <p><strong>{info.text}</strong></p>
            <p><small>{info.end}</small></p>
            <p><small>{info.situacao}</small></p>
            <p><small>{info.id}</small></p>
        </article>
    )
}