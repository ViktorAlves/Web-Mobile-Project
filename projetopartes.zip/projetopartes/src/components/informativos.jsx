import styles from "@/components/informativos.module.css"

export default function informativos(){
    
}