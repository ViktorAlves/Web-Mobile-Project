import React from "react";

function HomePage() {
  return (
    <div className="desktop">
      <div className="desktop-fundo">
        <div className="div">
          <div className="f_menu">
            <div className="menu" />
            <ul>
              <li>
                <a href="pagina1">Página Inicial</a>
              </li>
              <li>
                <a href="pagina2">Informações</a>
              </li>
              <li>
                <a href="pagina3">Login</a>
              </li>
            </ul>

            <img className="logo" alt="Logo" src="/logo.png" />
          </div>
          <h1>CADASTRO</h1>
          <label htmlFor="nome">Nome:</label>
          <br />
          <input
            type="text"
            id="nome"
            name="nome"
            required
            placeholder="nome"
          />
          <br />
          <label htmlFor="sobrenome"></label>
          <br />
          <input
            type="text"
            id="sobrenome"
            name="sobrenome"
            required
            placeholder="sobrenome"
          />
          <br />
          <label htmlFor="email"></label>
          <br />
          <input
            type="email"
            id="email"
            name="email"
            required
            placeholder="email"
          />
          <br />
          <label htmlFor="senha"></label>
          <br />
          <input
            type="password"
            id="senha"
            name="senha"
            required
            placeholder="senha"
          />
          <br />
          <label htmlFor="confirmar_senha"></label>
          <br />
          <input
            type="password"
            id="confirmar_senha"
            name="confirmar_senha"
            placeholder="confirmar senha"
            required
          />
          <br />
          <button type="submit">Confirmar Cadastro</button>
          <br></br>

          {/*
        representação do login 
      */}

          <h1>LOGIN</h1>
          <label htmlFor="email"></label>
          <br />
          <input
            type="email"
            id="email"
            name="email"
            required
            placeholder="email"
          />
          <br />
          <label htmlFor="senha"></label>
          <br />
          <input
            type="password"
            id="senha"
            name="senha"
            required
            placeholder="senha"
          />
          <br />
          <button type="submit">Login</button>
        </div>
      </div>
    </div>
  );
}

export default HomePage;
