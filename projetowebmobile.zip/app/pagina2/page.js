import Link from "next/link";

import React from "react";

export default function HomePage() {
  return (
    <div className="desktop">
      <div className="desktop-fundo">
        <div className="div">
          <div className="f_menu">
            <div className="menu" />
            <ul>
              <li>
                <a href="/">Página Inicial</a>
              </li>
              <li>
                <a href="pagina2">Informações</a>
              </li>
              <li>
                <a href="pagina3">Login</a>
              </li>
            </ul>
            <img className="logo" alt="Logo" src="/logo.png" />
          </div>
          <div className="t_pagina2A">Problemas</div>
          <p className="texto_pagina2A">
            A poluição tanto do ar quanto d’água, tem sido um problema
            recorrente nas últimas décadas, pois desde a revolução industrial
            inglesa, na segunda metade do século 18, em razão desse
            acontecimento, o homem teve uma rápida evolução no maquinário na
            indústria. Por conta dessa forte crescente manufatura, e sendo o
            principal combustível da época o carvão mineral, que é altamente
            poluente, devido a sua forte concentração de carbono (CO2) e o
            contínuo uso de fontes fosseis para a geração de energia, entre elas
            então as nucleares, que usam materiais radioativos como urânio (U),
            plutônio (Pu) e Tório (Th), as termelétricas, que tem a geração de
            energia vinda da combustão de diversos produtos, principalmente
            carvão e fontes ricos em CO2, além do constante crescente número de
            carros, que são movidos a gasolina, os quais são responsáveis por
            72,6% da geração de gases do efeito estufa e inclusive a exploração
            de derivados do petróleo como os plásticos, que quando descartados
            de maneira irregular poluem os rios e os mares, prejudicando a vida
            marinha. Vale citar os problemas que são gerados por usinas
            hidrelétricas, essas não geram poluição, porém o impacto ambiental,
            que é gerado durante a construção das usinas, e o pós construção, na
            medida em que o fluxo é alterado, pois do lado barrado, o volume
            aumenta, podendo causar inundações, e na outra área, fica baixo,
            causando uma grande perca na biodiversidade, tanto de plantas,
            quanto animal e mudando completamente a paisagem.
          </p>
        </div>
        <div className="t_pagina2B">Soluções</div>
        <p className="texto_pagina2B">
          Algumas das soluções desenvolvidas, foram os filtros nas chaminés das
          fábricas para reduzir a emissão de gás carbono, os mesmos foram
          adaptados para os escapamentos de carros, com o mesmo intuito de
          reduzir essa liberação após a queima da combustão. Grandes medidas
          tomadas pelos países para que as montadoras de carros comecem a
          fabricar carros elétricos, a diminuição de fabricação de plástico,
          incentivos para as pessoas aderirem ao máximo possível a reciclagem,
          na tentativa de se reduzir o descarte de sacos, garras, entre outros
          produtos feitos de plástico na natureza, visto que esse material,
          demora entorno de 500 anos para a sua decomposição. Ainda tem se visto
          as mudanças na forma de se criar energia, com uso de fontes
          renováveis, como solar e a eólica, que tem impactos mínimos no meio
          ambiente e além de serem recursos que dificilmente irão se esgotar.
        </p>
      </div>
    </div>
  );
}
