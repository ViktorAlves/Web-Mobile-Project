import Link from "next/link";
import React from "react";

export default function HomePage() {
  return (
    <div className="desktop">
      <div className="desktop-fundo">
        <div className="div">
          <div className="f_menu">
            <div className="menu" />
            <ul>
              <li>
                <a href="pagina1">Página Inicial</a>
              </li>
              <li>
                <a href="pagina2">Informações</a>
              </li>
              <li>
                <a href="pagina3">Login</a>
              </li>
            </ul>
            <img className="logo" alt="Logo" src="/logo.png" />
          </div>
          <div className="titulo">Sobre o nosso projeto</div>
          <p className="texto_pagina1A">
            Nosso projeto tem como objetivo informar acerca da poluição do ar,
            do solo e das águas, pois a melhor maneira de se evitar problemas,
            independente de qual ele seja, é com a educação, mostrando
            graficamente a poluição do ar e com o intuito de usá-lo para alertar
            as autoridades responsáveis para que tomem alguma medida com a
            finalidade de resolução do problema descrito no aplicativo. Tivemos
            como alvo o objetivo 3.9 Até 2030, reduzir substancialmente o número
            de mortes e doenças por produtos químicos perigosos, contaminação e
            poluição do ar e da água do solo, focado na comunidade da região
            metropolitana de São Paulo.
          </p>
          <div className="moldura"></div>
          <div className="texto_pagina1B">
            <img className="foto" alt="Foto" src="/poluicao.png" />
          </div>
          <p className="p">
            Além de causar doenças respiratórias e problemas de saúde, a
            poluição do ar, do solo e das águas pode afetar negativamente os
            ecossistemas, a biodiversidade e até mesmo a economia de uma região.
            Falaremos sobre as fontes principais de poluição no mundo, citar as
            principais consequências e alguma das contramedidas.
          </p>
        </div>
      </div>
    </div>
  );
}
